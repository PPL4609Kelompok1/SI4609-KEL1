<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;

class EnergyUsageReportController extends Controller
{
    public function index()
    {
        // Dummy data for demonstration - replace with actual data from your database
        $monthlyUsage = [
            'January' => 450,
            'February' => 420,
            'March' => 480,
            'April' => 400,
            'May' => 390,
            'June' => 410,
        ];

        $comparisonData = [
            'current_month' => 410,
            'previous_month' => 390,
            'percentage_change' => 5.13,
            'trend' => 'increase'
        ];

        return view('energy-usage.report', compact('monthlyUsage', 'comparisonData'));
    }
} 