<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EnergyUsageReportController;

Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/energy-usage-report', [EnergyUsageReportController::class, 'index'])->name('energy.usage.report');
